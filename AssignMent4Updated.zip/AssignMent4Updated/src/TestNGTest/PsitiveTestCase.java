package TestNGTest;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PsitiveTestCase {
	WebDriver driver;
	
	
	@BeforeTest(alwaysRun=true)
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		
		 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 
	}
	
	
	@AfterTest(alwaysRun=true)
	public void tearDown() {

		driver.close();

		driver.quit();

	}	
	
	@Test(groups= "smoke")
	//*********Test************************
	public void LoginTest()
	{
	// Open URL
	driver.get("http://zero.webappsecurity.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");





	driver.findElement(By.tagName("button")).click();
	driver.findElement(By.name("user_login")).sendKeys("username");
	driver.findElement(By.cssSelector("i.icon-question-sign")).click();
	driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
	WebElement rememberMeCheckbox = driver.findElement(By.id("user_remember_me"));
	 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	 boolean rmcIsSelected = rememberMeCheckbox.isSelected();

	 boolean rmcIsdisplyed = rememberMeCheckbox.isDisplayed();

	 boolean rmcIsEnabled = rememberMeCheckbox.isEnabled();
	 
	 
	 
	 
	 if  (rmcIsdisplyed)
	 {
		 System.out.println("Checkbox is displyed!");
		 
		 if (rmcIsEnabled) {
			 
			 System.out.println("Checkbox is Enabled");
			 if (rmcIsSelected) {
				 System.out.println("Checkbox is Selected");
			 }else {
				 rememberMeCheckbox.click();
				 System.out.println("Checkbox was not checked. I have checked it now!");
				 
			 }
		 }else {
			 System.out.println("Checkbox is not Enabled. Cannot do anything further!");
			 
		 }
	 }
	 else {
		 System.out.println("Checkbox is NOT displyed!!!");
		 
	 }





	driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("details-button")).click();
	driver.findElement(By.partialLinkText("Proceed to zero")).click();
	
	
	driver.findElement(By.xpath("//a[contains(text(),'Pay Bills')]")).click();
	driver.findElement(By.xpath("//a[contains(text(),'Purchase Foreign Currency')]")).click();

	//Explicit Wait
	WebDriverWait wait1 = new WebDriverWait(driver, 10);
	wait1.until(ExpectedConditions.titleContains("Zero - Pay Bills"));

	driver.findElement(By.id("purchase_cash")).click();

	Alert ZbAlert = driver.switchTo().alert();
	String Alert = ZbAlert.getText();
	System.out.println("The text on Zb alert is = '" + Alert + "'");

	ZbAlert.accept();
	WebDriverWait wait2 = new WebDriverWait(driver, 10);
	
	
	
	
	
	driver.findElement(By.xpath("//li[3]/a[1]")).click();
	
	
	driver.findElement(By.xpath("//a[@id='logout_link']")).click();
	
	Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	
	
	
	}
	
	@Test(groups= "smoke")
	public void transferFund()
	{
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Test Failed");
		
		
		





		driver.findElement(By.tagName("button")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("i.icon-question-sign")).click();
		driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
		WebElement rememberMeCheckbox = driver.findElement(By.id("user_remember_me"));
		 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 boolean rmcIsSelected = rememberMeCheckbox.isSelected();

		 boolean rmcIsdisplyed = rememberMeCheckbox.isDisplayed();

		 boolean rmcIsEnabled = rememberMeCheckbox.isEnabled();
		 
		 
		 
		 
		 if  (rmcIsdisplyed)
		 {
			 System.out.println("Checkbox is displyed!");
			 
			 if (rmcIsEnabled) {
				 
				 System.out.println("Checkbox is Enabled");
				 if (rmcIsSelected) {
					 System.out.println("Checkbox is Selected");
				 }else {
					 rememberMeCheckbox.click();
					 System.out.println("Checkbox was not checked. I have checked it now!");
					 
				 }
			 }else {
				 System.out.println("Checkbox is not Enabled. Cannot do anything further!");
				 
			 }
		 }
		 else {
			 System.out.println("Checkbox is NOT displyed!!!");
			 
		 }





		driver.findElement(By.name("submit")).click();
		//driver.findElement(By.id("details-button")).click();
		//driver.findElement(By.partialLinkText("Proceed to zero")).click();
		
		 driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
		 
		  WebElement dropDown= driver.findElement(By.id("tf_fromAccountId"));
		 Select sel= new Select(dropDown);
		 sel.selectByVisibleText("Savings(Avail. balance = $ 1000)");
		 
		driver.findElement(By.id("tf_amount")).sendKeys("500");
		
		 driver.findElement(By.id("tf_description")).sendKeys("Second transaction");
		
		driver.findElement(By.id("btn_submit")).click();
		
		
		driver.findElement(By.xpath("//li[3]/a[1]")).click();
		
		
		driver.findElement(By.xpath("//a[@id='logout_link']")).click();
		
		Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
		
		
		
		
	}
	
	
	
	

}
