package TestNGTest;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.AssertJUnit;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NegativeTestCases {

	WebDriver driver;

	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}

	
	@AfterTest
	public void tearDown() {

		driver.close();

		driver.quit();

	}

	@Test(priority = 1, groups = {"Regression" })
	public void LoginTest() {
		// Open URL
		driver.get("http://zero.webappsecurity.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		SoftAssert sa = new SoftAssert();

		AssertJUnit.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards1", "Test Failed");

		sa.assertAll();

	}

	@Test(groups =  {"Regression" }, priority = 2)
	public void invalidLogin() {
		// Open URL
		driver.get("http://zero.webappsecurity.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		SoftAssert sa = new SoftAssert();

		driver.findElement(By.tagName("button")).click();

		driver.findElement(By.name("user_login")).sendKeys("usernam");

		driver.findElement(By.cssSelector("i.icon-question-sign")).click();

		driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.id("details-button")).click();

		driver.findElement(By.id("proceed-link")).click();

		AssertJUnit.assertEquals(driver.getTitle(), "Zero - Account Summary", "Test Failed");

		sa.assertAll();

	}

	@Test(groups =  {"Regression"} , priority = 3)
	public void emptyLogin() {
		driver.get("http://zero.webappsecurity.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		SoftAssert sa = new SoftAssert();

		driver.findElement(By.tagName("button")).click();

		driver.findElement(By.name("user_login")).sendKeys("");

		driver.findElement(By.cssSelector("i.icon-question-sign")).click();

		driver.findElement(By.cssSelector("[type='password']")).sendKeys("");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.id("details-button")).click();

		driver.findElement(By.id("proceed-link")).click();

		AssertJUnit.assertEquals(driver.getTitle(), "Zero - Account Summary", "Test Failed");

		sa.assertAll();

	}

	@Test(groups = { "Regression" }, priority = 4)
	public void forgotPage() {
		driver.get("http://zero.webappsecurity.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		SoftAssert sa = new SoftAssert();

		driver.findElement(By.tagName("button")).click();

		driver.findElement(By.linkText("Forgot your password ?")).click();

		AssertJUnit.assertEquals(driver.getTitle(), "Zero - Forgotten Password1");
		
		sa.assertAll();
	}

	@Test(groups = { "Regression"} , priority = 5)
	public void verifyHomePage() {
		driver.get("http://zero.webappsecurity.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		SoftAssert sa = new SoftAssert();

		driver.findElement(By.tagName("button")).click();

		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("i.icon-question-sign")).click();
		driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");

		driver.findElement(By.name("submit")).click();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.partialLinkText("Proceed to zero")).click();
		
		
		String textverify=driver.findElement(By.xpath("//h2[contains(text(),'Cash Accounts')]")).getText();
		
		AssertJUnit.assertEquals(textverify, "Cash Accounts1");
		
		sa.assertAll();

	}

}
