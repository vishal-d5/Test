package com.qa.orangehrmlive.pages;

public class DashboardPage {

}
