package com.qa.orangehrmlive.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.orangehrmlive.base.TestBase;
import com.qa.orangehrmlive.pages.LoginPage;


public class LoginPagetestcases  extends TestBase{
	 LoginPage lp;

	@BeforeMethod
	public void setUp() {
		initialization();
		lp=new LoginPage();
		
	}
	
	@AfterMethod
	public void tearDown()
	{ 
		
		driver.close();
		driver.quit();
	}
	
	@Test
	  public void FinalTestCase() {
		  lp.finalverify();
		  Assert.assertEquals(lp.checkData.getText(), "vishal@gmail.com");
	  }

}
