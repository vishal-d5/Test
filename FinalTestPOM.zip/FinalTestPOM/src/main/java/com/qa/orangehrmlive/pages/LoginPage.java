package com.qa.orangehrmlive.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.orangehrmlive.base.TestBase;

public class LoginPage extends TestBase {
	@FindBy(id="frmLogin")
	WebElement username;

	@FindBy(id="txtPassword")
	WebElement password;

	@FindBy(id="btnLogin")
	WebElement LoginButton;
	
	@FindBy(id="menu_recruitment_viewRecruitmentModule")
     WebElement recruitmentMenu;
	
	@FindBy(id="menu_recruitment_viewCandidates")
	WebElement candidatemenu;
	
	@FindBy(id="btnAdd")
	WebElement AddBtn;
	
	@FindBy(id="addCandidate_firstName")
	WebElement addCandidatefirstname;
	
	@FindBy(id="addCandidate_middleName")
	WebElement addCandidatemiddlename;
	
	@FindBy(id="addCandidate_lastName")
	WebElement addCandidatelastname;

	@FindBy(id="addCandidate_email")
	WebElement addEmail;
	
	@FindBy(id="addCandidate_contactNo")
	WebElement addContactNo;
	
	@FindBy(id="addCandidate_vacancy")
	WebElement addVacancy;
	
	
	@FindBy(id="btnSave")
	WebElement btnSave;
	
	@FindBy(xpath="/html[1]/body[1]/div[1]/div[3]/div[2]/div[2]/form[1]/div[3]/table[1]/tbody[1]/tr[1]/td[2]")
	public
	WebElement checkData;
	
	
	Actions actions;
	public LoginPage() {
		 PageFactory.initElements(driver, this);
	 }
	
	public DashboardPage logIn() {
		username.sendKeys(prop.getProperty("username"));
	password.sendKeys(prop.getProperty("password"));
		LoginButton.click();
		return new DashboardPage();		}
	
	
	public void myAction() {
     actions = new Actions(driver);
	actions.moveToElement(recruitmentMenu).click();
	    candidatemenu.click();
	}
	
	
	public void addCandidate() 
	{
		addCandidatefirstname.sendKeys(prop.getProperty("firstname"));
		addCandidatemiddlename.sendKeys(prop.getProperty("middlename"));
		addCandidatelastname.sendKeys(prop.getProperty("lastname"));
		addEmail.sendKeys(prop.getProperty("email"));
		btnSave.click();
		
		
		
		
		
	}
	
	 public void  finalverify() {
		 logIn();
		 myAction();
		 addCandidate();
	 }
	
	

}
